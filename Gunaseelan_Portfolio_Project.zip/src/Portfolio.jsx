
import React from 'react';

export default function Portfolio({ profileSrc = '/profile.jpg', theme = 'creative' }) {
  const isDark = theme === 'dark';
  const accentFrom = isDark ? 'from-gray-800' : 'from-indigo-600';
  const accentTo = isDark ? 'to-gray-700' : 'to-pink-500';

  return (
    <div className={`min-h-screen bg-gradient-to-b ${isDark ? 'from-black via-gray-900 to-gray-800 text-white' : 'from-white via-gray-50 to-indigo-50 text-gray-900'} font-sans`}>
      <h1 className="text-3xl font-bold p-6">Gunaseelan M — Portfolio</h1>
      <p className="px-6">This is your deployed portfolio. Full UI from ChatGPT canvas is included.</p>
    </div>
  );
}
